document.addEventListener('DOMContentLoaded', function () {
	chrome.alarms.create("feed", {delayInMinutes: 0, periodInMinutes: 1} );
});
chrome.alarms.onAlarm.addListener(function(alarm) {
	var xhr = new XMLHttpRequest();
	xhr.open("GET", "http://soundation.com/feed", true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			html = xhr.responseText;
			html = html.replace(/<img\b[^>]*>/ig, '');
			var sCommunity = $(html).find("a[href='/feed']")[0].innerText;
			var numAlerts = sCommunity.match(/(\d+)/);
			if (numAlerts != null) {
				console.log(numAlerts[0]);
				chrome.browserAction.setBadgeText({text:numAlerts[0]});
			} else {
				console.log("modation: no notifs");
				chrome.browserAction.setBadgeText({text:""})
			}
		}
	}
	xhr.send();
});