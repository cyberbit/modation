function install_notice() {
    if (localStorage.getItem('install_time'))
        return;

    var now = new Date().getTime();
    localStorage.setItem('install_time', now);
    chrome.tabs.create({url: "options.html"});
}
install_notice();
var hashes = [];
document.addEventListener('DOMContentLoaded', function () {
	chrome.alarms.create("feed", {delayInMinutes: 0, periodInMinutes: 1} );
});
chrome.alarms.onAlarm.addListener(function(alarm) {
	var xhr = new XMLHttpRequest();
	xhr.open("GET", "http://soundation.com/feed", true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			html = xhr.responseText;
			html = html.replace(/<img\b[^>]*>/ig, '').replace(/<span class=\"time\">.*<\/span>/ig, '');
			var oHtml = $(html);
			var email = oHtml.find('.email').text();
			var emailHash = email.hashCode();
			if (typeof localStorage[email] == "undefined") {
				localStorage[email] = emailHash;
				localStorage[emailHash + ".desktop_notifs"] = "on";
			}
			var aside = oHtml.find('aside')[0];
			if (typeof aside == "undefined") {
				chrome.browserAction.setTitle({title:"Please login to view notifications"});
				chrome.browserAction.setBadgeBackgroundColor({color:"#9a9a9a"});
				chrome.browserAction.setBadgeText({text:"?"});
			}
			var asideHTML = aside.outerHTML;
			var asideHash = String(asideHTML.hashCode());
			//console.log(asideHash);
			var sCommunity = oHtml.find("a[href='/feed']")[0].innerText;
			var numAlerts = sCommunity.match(/(\d+)/);
			if (numAlerts != null) {
				var iTotal = 0, authors = [];
				$(asideHTML).find('a.author').each(function() {
					author = $(this).text();
					if (authors.indexOf(author) == -1) authors.push(author);
					++iTotal;
				});
				var iAuthors = authors.length, iOthers = iAuthors - 3, i = 0, authorString = iTotal + " new from ";
				for (i = 0; i < 2 && i < (iAuthors - 1); ++i) {
					authorString += authors[i] + ", ";
				}
				authorString += authors[i];
				if (iOthers > 0) authorString += ", plus " + iOthers + " other" + (iOthers > 1 ? "s" : "");
				console.log(authorString);
				//console.log(numAlerts[0]);
				chrome.browserAction.setTitle({title:authorString});
				chrome.browserAction.setBadgeBackgroundColor({color:"#d00"});
				chrome.browserAction.setBadgeText({text:numAlerts[0]});
				if ((hashes.indexOf(asideHash) == -1) && doNotifs(emailHash)) chrome.notifications.create(asideHash, {
					type: "basic",
					iconUrl: "iconapp.png",
					title: "Soundation Notifications",
					message: numAlerts[0] + " new notification" + (parseInt(numAlerts[0]) > 1 ? "s" : ""),
					contextMessage: authorString.replace(/\d* new /, "")
				}, function(notificationId) {hashes.push(asideHash)});
			} else {
				console.log("modation: no notifs");
				chrome.browserAction.setTitle({title:"No new notifications :("});
				chrome.browserAction.setBadgeText({text:""})
			}
		}
	}
	xhr.send();
});
function doNotifs(hash) {
	if (typeof hash == "undefined") return true;
	switch (localStorage[hash + ".desktop_notifs"]) {
		case "on":
			return true;
			break;
		case "off":
			return false;
			break;
	}
}
String.prototype.hashCode = function(){
    var hash = 0, i, char;
    if (this.length == 0) return hash;
    for (i = 0, l = this.length; i < l; i++) {
        char  = this.charCodeAt(i);
        hash  = ((hash<<5)-hash)+char;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
};