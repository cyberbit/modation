
$(document).ready(function() {
	$('#pdalogincheck').click(getLogin);
	$('#save').click(save_options);
	$('#status').hide();
	getLogin();
});
//Grab email and resore settings
function getLogin() {
	if (!$('#logincheck .loader').length) {
		$('#pdalogincheck').before("<img class=\"loader\" src=\"loadingf5t.gif\">");
		$('#logincheck .loader').hide();
		$('#logincheck .loader').fadeIn(150);
	}
	var xhr = new XMLHttpRequest();
	xhr.open("GET", "http://soundation.com/account/profile", true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			html = xhr.responseText;
			html = html.replace(/<img\b[^>]*>/ig, '');
			var oHtml = $(html);
			var email = oHtml.find('.email').text();
			if (email == "") {
				$('#save').prop("disabled", true)
					.addClass("nosave");
				$('#status').html("<strong style=\"color: darkred\">Please <a href=\"http://soundation.com/feed\" target=\"_new\">login</a> to change settings!</strong>");
				$('#status').fadeIn(150);
			} else {
				$('#email').val(email);
				restore_options(email);
			}
			$('#logincheck .loader').fadeOut(150, function(){$(this).remove();});
		}
	}
	xhr.send();
}
// Saves options to localStorage.
function save_options() {
	var email = $('#email').val();
	var emailHash = email.hashCode();
	var desktop_notifs = $('[name^="desktop_notifs"]:checked').val();
	localStorage[email] = emailHash;
	localStorage[emailHash + ".desktop_notifs"] = desktop_notifs;
	
	// Update status to let user know options were saved.
	status("Settings saved.");
}

function status(msg) {
	msg = (typeof msg == "undefined" ? "Something happened." : msg);
	
	$('#status').fadeOut(($('#status').html() ? 150 : 0), function() {
		$('#status').html(msg);
	});
	$('#status').fadeIn(150);
	setTimeout(function() {
		$('#status').fadeOut(150, function() {
			$('#status').html("");
		});
	}, 1300);
}

// Restores options to saved values from localStorage.
function restore_options(email) {
	var emailHash = localStorage[email];
	
	//set up defaults
	if (typeof emailHash == "undefined") {
		$('#desktop_notifs_on').prop("checked", true);
		save_options();
	} else {
		//Parse desktop notification settings
		var desktop_notifs = localStorage[emailHash + ".desktop_notifs"];
		$('#desktop_notifs_' + desktop_notifs).prop("checked", true);
		
		status("Settings restored.");
	}
}
String.prototype.hashCode = function(){
    var hash = 0, i, char;
    if (this.length == 0) return hash;
    for (i = 0, l = this.length; i < l; i++) {
        char  = this.charCodeAt(i);
        hash  = ((hash<<5)-hash)+char;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
};