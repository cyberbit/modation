var hashes = [];
document.addEventListener('DOMContentLoaded', function () {
	chrome.alarms.create("feed", {delayInMinutes: 0, periodInMinutes: 1} );
});
chrome.alarms.onAlarm.addListener(function(alarm) {
	var xhr = new XMLHttpRequest();
	xhr.open("GET", "http://soundation.com/feed", true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			html = xhr.responseText;
			html = html.replace(/<img\b[^>]*>/ig, '').replace(/<span class=\"time\">.*<\/span>/ig, '');
			var asideHash = String($(html).find('aside')[0].outerHTML.hashCode());
			console.log(asideHash);
			var sCommunity = $(html).find("a[href='/feed']")[0].innerText;
			var numAlerts = sCommunity.match(/(\d+)/);
			if (numAlerts != null) {
				//console.log(numAlerts[0]);
				chrome.browserAction.setBadgeText({text:numAlerts[0]});
				if (hashes.indexOf(asideHash) == -1) chrome.notifications.create(asideHash, {
					type: "basic",
					iconUrl: "iconapp.png",
					title: "Soundation Notifications",
					message: numAlerts[0] + " new notification" + (parseInt(numAlerts[0]) > 1 ? "s" : "")
				}, function(notificationId) {hashes.push(asideHash)});
			} else {
				console.log("modation: no notifs");
				chrome.browserAction.setBadgeText({text:""})
				/*chrome.notifications.create("modationnonotifs", {
					type: "basic",
					iconUrl: "iconapp.png",
					title: "Soundation Notifications",
					message: "No new notifications"
				}, function(notificationId) {});*/
			}
		}
	}
	xhr.send();
});
String.prototype.hashCode = function(){
    var hash = 0, i, char;
    if (this.length == 0) return hash;
    for (i = 0, l = this.length; i < l; i++) {
        char  = this.charCodeAt(i);
        hash  = ((hash<<5)-hash)+char;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
};