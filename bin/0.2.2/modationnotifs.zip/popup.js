$(document).ready(function() {
	parseNotifs();
	/*var xhr = new XMLHttpRequest();
	xhr.open("GET", "http://soundation.com/feed", true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			html = xhr.responseText;
			html = html.replace(/<img\b[^>]*>/ig, '');
			var aside = $(html).find('aside')[0];
			var parse = "<strong>Unknown error</strong>";
			if (typeof aside == "undefined") {
				parse = "<aside>";
					parse += "<div class=\"container\">";
						parse += "<div class=\"wrapper notifications last\">";
							parse += "<h3>You are not logged in</h3>";
							parse += "<span class=\"empty\">Please <a href=\"/feed\">login</a> to view notifications.</span>";
						parse += "</div>";
					parse += "</div>";
				parse += "</aside>";
			} else {
				parse = aside.outerHTML;
			}
			$('.main-wrapper').html(parse);
			$('.main-wrapper a').each(function() {
				var href = $(this).attr('href');
				$(this).attr('href', 'http://soundation.com' + href);
				$(this).attr('target', '_tab');
			});
			$('form').each(function() {
				var action = $(this).attr('action');
				$(this).attr('action', 'http://soundation.com' + action);
				$(this).attr('target', 'clearcatcher');
			});
			$('input.clear-notification').each(function() {
				$(this).click(function() {
					$('div.notifications div').slideUp();
					$('div.notifications h3').after('<span class=\"empty\"><img src="loading.gif"> Just a moment...</span>');
					$('div.notifications .empty').hide();
					$('div.notifications .empty').fadeIn();
					setTimeout(function(){refresh()}, 1000);
				});
			});
			var sCommunity = $(html).find("a[href='/feed']")[0].innerText;
			var numAlerts = sCommunity.match(/(\d+)/);
			if (numAlerts != null) {
				console.log(numAlerts[0]);
				chrome.browserAction.setBadgeText({text:numAlerts[0]});
			} else {
				console.log("modation: no notifs");
				chrome.browserAction.setBadgeText({text:""})
			}
		}
	}
	xhr.send();*/
});
function refresh() {location.reload()}
function parseNotifs() {
	var xhr = new XMLHttpRequest();
	xhr.open("GET", "http://soundation.com/feed", true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			html = xhr.responseText;
			html = html.replace(/<img\b[^>]*>/ig, '');
			var aside = $(html).find('aside')[0];
			var parse = "<strong>Unknown error</strong>";
			if (typeof aside == "undefined") {
				parse = "<aside>";
					parse += "<div class=\"container\">";
						parse += "<div class=\"wrapper notifications last\">";
							parse += "<h3>You are not logged in</h3>";
							parse += "<span class=\"empty\">Please <a href=\"/feed\">login</a> to view notifications.</span>";
						parse += "</div>";
					parse += "</div>";
				parse += "</aside>";
			} else {
				parse = aside.outerHTML;
			}
			$('.main-wrapper').html(parse);
			$('.main-wrapper a').each(function() {
				var href = $(this).attr('href');
				$(this).attr('href', 'http://soundation.com' + href);
				$(this).attr('target', '_tab');
			});
			$('form').each(function() {
				var action = $(this).attr('action');
				$(this).attr('action', 'http://soundation.com' + action);
				$(this).attr('target', 'clearcatcher');
			});
			$('input.clear-notification').each(function() {
				$(this).click(function() {
					$(this).parents('div.notifications div').slideUp();
					if (!$('div.notifications h3 img').length) {
						//$('div.notifications h3').after('<span class=\"empty\"><img src="loading.gif"> Just a moment...</span>');
						$('div.notifications h3').append('<img src="loading.gif" style="float: right">');
						$('div.notifications .empty').fadeIn();
						parseNotifs();
					}
				});
			});
			var sCommunity = $(html).find("a[href='/feed']")[0].innerText;
			var numAlerts = sCommunity.match(/(\d+)/);
			if (numAlerts != null) {
				console.log(numAlerts[0]);
				chrome.browserAction.setBadgeText({text:numAlerts[0]});
			} else {
				console.log("modation: no notifs");
				chrome.browserAction.setBadgeText({text:""})
			}
		}
	}
	xhr.send();
}