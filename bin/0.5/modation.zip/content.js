//Needs to be up here for original hash check (ugh)
String.prototype.hashCode = function(){
    var hash = 0, i, char;
    if (this.length == 0) return hash;
    for (i = 0, l = this.length; i < l; i++) {
        char  = this.charCodeAt(i);
        hash  = ((hash<<5)-hash)+char;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
};

var modationStorage = [];
chrome.runtime.sendMessage({method: "storage"}, function(r) {
	modationStorage = r;
	init();
});

/* ======== HELPERS ======== */

function init() {
	var hash = getEmailHash();
	//alert(hash);
	//alert(JSON.stringify(modationStorage));
	if (doStickySidebars(hash)) sticky_sidebars();
	if (doGroupMods(hash) && $("div#main:has(.group)").length) {
		addJQuery(group_mods);
	}
	if (doPlayerDownloads(hash)) player_downloads();
}

//suggestion by @kennebec: http://stackoverflow.com/a/3620258/3402854
function addCode(parent, code) {
	var doc = parent[0]; //Get document from jQuery selector
    var JS = doc.createElement('script');
    JS.text = code;
    doc.body.appendChild(JS);
}

function addLinkedCode(parent, src) {
	var head = parent.find("head");
	head.append("<script src='" + src + "'></script>");
}

function addCSS(parent, css) {
	var head = parent.find("head");
	head.append("<style>" + css + "</style>");
}

function addJQuery(callback) {
    var includeFunctions = [toggleOldGroups, toggleOnlyAdminGroups, resetModLinks, minifyGroups];
    var script = document.createElement("script");
    script.setAttribute("src", "http://code.jquery.com/jquery-1.10.2.min.js");
    script.addEventListener('load', function () {
        var script = document.createElement("script");
        var sIncludeFunctions = "";
        includeFunctions.forEach(function (f) {
            sIncludeFunctions += f.toString();
        });
        script.textContent = "window.jQ=jQuery.noConflict(true);(" + callback.toString() + ")();" + sIncludeFunctions;
        document.body.appendChild(script);
    }, false);
    document.body.appendChild(script);
}

function getEmailHash() {
	var email = $(".email").text();
	return email.hashCode();
}

function doStickySidebars(hash) {
	if ((typeof hash == "undefined") || (modationStorage[hash + ".sticky_sidebars"] == "on")) { return true; }
	else if (modationStorage[hash + ".sticky_sidebars"] == "off") { return false; }
	return true;
}

function doGroupMods(hash) {
	if ((typeof hash == "undefined") || (modationStorage[hash + ".group_mods"] == "on")) { return true; }
	else if (modationStorage[hash + ".group_mods"] == "off") { return false; }
	return true;
}

function doPlayerDownloads(hash) {
	if ((typeof hash == "undefined") || (modationStorage[hash + ".player_downloads"] == "on")) { return true; }
	else if (modationStorage[hash + ".player_downloads"] == "off") { return false; }
	return true;
}

/* ======== COMMUNITY MODS ======== */

/* Sticky Sidebars */
function sticky_sidebars() {
	$("aside").stick_in_parent({offset_top: 10});
}

/* Group Mods */
function group_mods() {
    var minifiedStyles = "div.row.group.minified { padding: 4px; } div.img.minified, div.img.minified img { width: 20px !important; height: 20px !important; } div.info.minified { min-height: 20px !important; margin-left: 24px !important; } p.last-activity.minified { float: right; display: inline; } p.last-activity.minified:before { content: \"(\"; } p.last-activity.minified:after { content: \")\"; } div.admin.minified a { margin-top: -2px !important; }";
    var style = document.createElement("style");
    style.textContent = minifiedStyles;
    style.setAttribute("type", "text/css");
    document.head.appendChild(style);
    $("div#main h2").after("<div id=\"groupmods\" style=\"display: none; padding: 8px; background: #e5f3d6; border: 1px solid #709343; border-radius: 2px\">cyberbit's Group Mods: <p><a id=\"oldgroups\" href=\"javascript:;\" onclick=\"toggleOldGroups(0, this)\">Hide Old Groups</a> | <a id=\"admingroups\"href=\"javascript:;\" onclick=\"toggleOnlyAdminGroups(0, this)\">Show Only Admin Groups</a> | <a id=\"minifygroups\"href=\"javascript:;\" onclick=\"minifyGroups(1, this)\">Minify Groups</a></p></div>");
	$("div#groupmods").fadeIn(2000);
}

/* Player Downloads */
function player_downloads() {
	$('iframe[src*="/player/"]').load(function() {
		var player = $(this).contents();
		addCSS(player, '#title-bar #downloads { display: none; background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAICAYAAAArzdW1AAAABmJLR0QAJAAkACTORThWAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3gQHEDcJeUryZgAAAFtJREFUGNONjjEKwDAMA002TZ3yA/n1/pb8DndJg6Gh9MaTEDJbkGQ1SPLJhv1grJV5CrcnOesDknOYmWVmnpaWv/ZpSeoLktTP72JERFVVRMSr8AAA7u4A0P0NFStRvu/GlrMAAAAASUVORK5CYII=") no-repeat 13px 6px; float: right; padding: 0 0 0 28px; color: white; height: 19px;}');
		addCSS(player, "#circleG{position:relative;top:8px;width:10.5px}.circleG{background-color:#FFF;float:left;height:2px;margin-left:1px;width:2px;-webkit-animation-name:bounce_circleG;-webkit-animation-duration:1.5s;-webkit-animation-iteration-count:infinite;-webkit-animation-direction:linear;-webkit-border-radius:1px}#circleG_1{-webkit-animation-delay:.3s}#circleG_2{-webkit-animation-delay:.7s}#circleG_3{-webkit-animation-delay:.9s}@-webkit-keyframes bounce_circleG{50%{background-color:#262627}}");
		player.find("span#likes").before('<span id="downloads"><div id="circleG"><div id="circleG_1" class="circleG"></div><div id="circleG_2" class="circleG"></div><div id="circleG_3" class="circleG"></div></div></span>');
		player.find("span#downloads").fadeIn(500);
		var trackPage = player.find("a").attr("href");
		$.get(trackPage, function(data) {
			player.find(".circleG").fadeOut(200, function() {
				$(this).remove();
				var downloads = $(data).find("span.downloads").text();
				var oDownloads = '<span id="downloads_count" style="display: none">' + downloads + '</span>';
				player.find("span#downloads").html(oDownloads);
				player.find("#downloads_count").fadeIn(200);
			});
		});
	});
}

/* Group Mods - Toggle old groups */
function toggleOldGroups(iToggle, oFrom) {
    resetModLinks(1, iToggle, oFrom);
    jQ(oFrom).parents("#groupmods").nextAll('.list-container').first().children("div.row.group").each(function (i, e) {
        elem = jQ(this).find("p.last-activity")[0];
        if ((typeof elem === 'undefined' || elem.innerHTML.indexOf("year") >= 0 || elem.innerHTML.indexOf("month") >= 0 || elem.innerHTML.search("([5-9]|[123]\\d) days") >= 0) && !(jQ(this).find("div.admin").length > 0)) {
            node = jQ(this);
            (iToggle ? node.slideDown(600) : node.slideUp(600));
        } else {
            node = jQ(this);
            node.slideDown(600);
        }
    });
    resetModLinks(2, 1, oFrom);
}

/* Group Mods - Toggle only admin groups */
function toggleOnlyAdminGroups(iToggle, oFrom) {
    resetModLinks(2, iToggle, oFrom);
    jQ(oFrom).parents("#groupmods").nextAll('.list-container').first().children("div.row.group").each(function (i, e) {
        if (jQ(this).find("div.admin").length === 0) {
            node = jQ(this);
            (iToggle ? node.slideDown(600) : node.slideUp(600));
        }
    });
    (iToggle ? resetModLinks(1, iToggle, oFrom) : null);
}

/* Group Mods - Reset mod links */
function resetModLinks(iMode, iToggle, oFrom) {
	//alert(iMode + " " + iToggle);
    switch (iMode) {
        case 0: //All links reset
            jQ(oFrom).closest("a#oldgroups").attr("onclick", "toggleOldGroups(" + (iToggle ? "0" : "1") + ", this)").html((iToggle ? "Hide" : "Show") + " Old Groups");
            jQ(oFrom).closest("a#admingroups").attr("onclick", "toggleOnlyAdminGroups(" + (iToggle ? "0" : "1") + ", this)").html((iToggle ? "Show Only Admin" : "Show All") + " Groups");
            break;
        case 1: //Old groups link reset
            jQ(oFrom).closest("a#oldgroups").attr("onclick", "toggleOldGroups(" + (iToggle ? "0" : "1") + ", this)").html((iToggle ? "Hide" : "Show") + " Old Groups");
            break;
        case 2: //Admin groups link reset
            jQ(oFrom).closest("a#admingroups").attr("onclick", "toggleOnlyAdminGroups(" + (iToggle ? "0" : "1") + ", this)").html((iToggle ? "Show Only Admin" : "Show All") + " Groups");
            break;
    }
}

/* Group Mods - Minify groups */
function minifyGroups(iToggle, oFrom) {
    jQ(oFrom).parents("#groupmods").nextAll('.list-container').first().children("div.row.group").each(function (i, e) {
        isAdmin = jQ(this).find("div.admin").length > 0;
        img = jQ(this).find("div.img")[0].outerHTML;
        link = jQ(this).find("a.name")[0].outerHTML;
        vLastActivity = jQ(this).find("p.last-activity");
        lastActivity = (vLastActivity.length > 0 ? vLastActivity[0].outerHTML.replace("Last activity ", "").replace(" ago", "") : '');
        minifiedContent = img + "<div class=\"info\">" + link + (isAdmin ? "<span id=\"spacer\" style=\"width: 80px; height: 20px; float:right;\"></span>" : "") + lastActivity;
        if (isAdmin) {
            adminButton = jQ(this).find("div.admin a")[0].outerHTML;
            jQ(this).find("div.admin").html(adminButton);
            admin = jQ(this).find("div.admin")[0].outerHTML;
            minifiedContent += admin + "</div>";
        }
        jQ(this).html(minifiedContent);
    });
    jQ(oFrom).parents("#groupmods").nextAll('.list-container').first().find("div.row.group, div.img, div.info, p.last-activity, div.admin").addClass("minified");
}