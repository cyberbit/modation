Project pages for Modation, published at http://cyberbit.github.io/modation
